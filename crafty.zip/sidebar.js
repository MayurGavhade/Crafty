
const LIMIT = 40;
let used = 0;
const counter = document.getElementById('usageCounter');
counter.textContent = `Used ${used} / ${LIMIT}`;

document.getElementById('copyBtn').onclick = () => {
  navigator.clipboard.writeText(document.getElementById('output').value);
};
